import './App.css';
import Products from './Components/Products/Product';
import {BrowserRouter, Routes, Route} from "react-router-dom";

function App() {
  return (
    <div className="App">
    <Products/>
    </div>
  );
}

export default App;
